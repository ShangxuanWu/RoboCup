#ifndef __ATTACK_H
#define __ATTACH_H

#include "utils.h"
#include "UP_UART2Parser.h"
#include "graph.h"
#include "function.h"
#include "control.h"
#include "actor.h"

void attack_init(void);

#endif