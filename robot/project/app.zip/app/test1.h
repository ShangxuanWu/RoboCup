//
int a1[]={1,2,3};
int a2[]={3,2,1};

void test1()
{
  uint8 fieldSensor[10];
  GetFieldSensors(fieldSensor);
  
  if(fieldSensor[4]);
}

