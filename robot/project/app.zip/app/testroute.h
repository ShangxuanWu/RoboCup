#ifndef __TESTROUTE_H
#define __TESTROUTE_H

void testroute_init(void);
void testroute_run(void);

#endif